package com.zr.yahoo.bean;

public class Users {
	/*
	 * �û���ʵ����:
	 * 
	 * �û����� userId 
	 * �û��� uName 
	 * ���� uPassword 
	 * ���� uBirthday 
	 * ͷ�� uEmotion 
	 * �Ա� uSex 
	 * ע������ uRegdate 
	 * �û���� uType
	 */
	private int userId;
	private String uName;
	private String uPassword;
	private String uBirthday;
	private String uEmotion;
	private int uSex;
	private String uRegdate;
	private int uType;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	public String getuBirthday() {
		return uBirthday;
	}
	public void setuBirthday(String uBirthday) {
		this.uBirthday = uBirthday;
	}
	public String getuEmotion() {
		return uEmotion;
	}
	public void setuEmotion(String uEmotion) {
		this.uEmotion = uEmotion;
	}
	public int getuSex() {
		return uSex;
	}
	public void setuSex(int uSex) {
		this.uSex = uSex;
	}
	public String getuRegdate() {
		return uRegdate;
	}
	public void setuRegdate(String uRegdate) {
		this.uRegdate = uRegdate;
	}
	public int getuType() {
		return uType;
	}
	public void setuType(int uType) {
		this.uType = uType;
	}	
}
