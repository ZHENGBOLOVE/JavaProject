package com.zr.yahoo.bean;

public class Reply {
	/*
	 * ������ʵ���ࣺ
	 * 
	 * ������� rId 
	 * �������� rTid 
	 * �û����� rUid 
	 * ͼƬ rEmotion 
	 * �������� rTopic 
	 * �������� rContents
	 * ����ʱ�� rTime 
	 */
	private int rId;
	private int rTid;
	private int rUid;
	private String rEmotion;
	private String rTopic;
	private String rContents;
	private String rTime;
	
	public int getrId() {
		return rId;
	}
	public void setrId(int rId) {
		this.rId = rId;
	}
	public int getrTid() {
		return rTid;
	}
	public void setrTid(int rTid) {
		this.rTid = rTid;
	}
	public int getrUid() {
		return rUid;
	}
	public void setrUid(int rUid) {
		this.rUid = rUid;
	}
	public String getrEmotion() {
		return rEmotion;
	}
	public void setrEmotion(String rEmotion) {
		this.rEmotion = rEmotion;
	}
	public String getrTopic() {
		return rTopic;
	}
	public void setrTopic(String rTopic) {
		this.rTopic = rTopic;
	}
	public String getrContents() {
		return rContents;
	}
	public void setrContents(String rContents) {
		this.rContents = rContents;
	}
	public String getrTime() {
		return rTime;
	}
	public void setrTime(String rTime) {
		this.rTime = rTime;
	}

}
