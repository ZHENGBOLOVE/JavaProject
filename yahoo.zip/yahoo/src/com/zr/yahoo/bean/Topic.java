package com.zr.yahoo.bean;

public class Topic {
	/*
	 * ������ʵ���ࣺ
	 * 
	 * ������� tId
	 * ����� tSid
	 * �û���� tUid
	 * ������ tReplyCount 
	 * ����ͼƬ tEmotion
	 * ���� tPic
	 * �������� tTopic
	 * ���� tContents
	 * ����ʱ�� tTime
	 * ����� tClickCount
	 */
	private int tId;
	private int tSid;
	private int tUid;
	private int tReplyCount;
	private String tEmotion;
	private String tTopic;
	private String tContents;
	private String tTime;
	private int tClickCount;
	public int gettId() {
		return tId;
	}
	public void settId(int tId) {
		this.tId = tId;
	}
	public int gettSid() {
		return tSid;
	}
	public void settSid(int tSid) {
		this.tSid = tSid;
	}
	public int gettUid() {
		return tUid;
	}
	public void settUid(int tUid) {
		this.tUid = tUid;
	}
	public int gettReplyCount() {
		return tReplyCount;
	}
	public void settReplyCount(int tReplyCount) {
		this.tReplyCount = tReplyCount;
	}
	public String gettEmotion() {
		return tEmotion;
	}
	public void settEmotion(String tEmotion) {
		this.tEmotion = tEmotion;
	}
	public String gettTopic() {
		return tTopic;
	}
	public void settTopic(String tTopic) {
		this.tTopic = tTopic;
	}
	public String gettContents() {
		return tContents;
	}
	public void settContents(String tContents) {
		this.tContents = tContents;
	}
	public String gettTime() {
		return tTime;
	}
	public void settTime(String tTime) {
		this.tTime = tTime;
	}
	public int gettClickCount() {
		return tClickCount;
	}
	public void settClickCount(int tClickCount) {
		this.tClickCount = tClickCount;
	}
	
}
