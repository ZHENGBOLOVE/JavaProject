package com.zr.yahoo.bean;

public class Comments {
	/*
	 * ���۱�ʵ���ࣺ
	 * 
	 * ���۱�� cId
	 * ���ۻ������ cRid
	 * ���۷������ cTid
	 * �������� cContents
	 * ���� cZan
	 * ������� cNotZan
	 * �û���� cUserId
	 * ����ʱ�� cTime
	 */
	private int cId;
	private int cRid;
	private int cTid;
	private String cContents;
	private int cZan;
	private int cNotZan;
	private int cUserId;
	private String cTime;
	
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public int getcRid() {
		return cRid;
	}
	public void setcRid(int cRid) {
		this.cRid = cRid;
	}
	public int getcTid() {
		return cTid;
	}
	public void setcTid(int cTid) {
		this.cTid = cTid;
	}
	public String getcContents() {
		return cContents;
	}
	public void setcContents(String cContents) {
		this.cContents = cContents;
	}
	public int getcZan() {
		return cZan;
	}
	public void setcZan(int cZan) {
		this.cZan = cZan;
	}
	public int getcNotZan() {
		return cNotZan;
	}
	public void setcNotZan(int cNotZan) {
		this.cNotZan = cNotZan;
	}
	public int getcUserId() {
		return cUserId;
	}
	public void setcUserId(int cUserId) {
		this.cUserId = cUserId;
	}
	public String getcTime() {
		return cTime;
	}
	public void setcTime(String cTime) {
		this.cTime = cTime;
	}

}
