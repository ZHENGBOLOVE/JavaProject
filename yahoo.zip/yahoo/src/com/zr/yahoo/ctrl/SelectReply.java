package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Reply;
import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.ReplyDao;
import com.zr.yahoo.dao.TopicDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class SelectReply
 */
public class SelectReply extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectReply() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*
		 * ��ȡ������Ϣ
		 */
		
		int tid = Integer.parseInt(request.getParameter("tid"));
				
		ReplyDao rd = new ReplyDao();
		UsersDao ud = new UsersDao();
		TopicDao td = new TopicDao();
		
		try {
			/*rlist = rd.selectAll();*/
			
			List<Users> ulist = ud.selectAllUsers();
			List<Topic> tlist = td.selectAll();
			List<Reply> rlist = rd.selectByrTid(tid);
			
			/*request.setAttribute("r", r);*/
			request.setAttribute("rlist", rlist);
			request.setAttribute("ulist", ulist);
			request.setAttribute("tlist", tlist);
			
			request.getRequestDispatcher("GetAllContent.jsp").forward(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
