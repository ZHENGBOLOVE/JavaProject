package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.dao.TopicDao;

/**
 * Servlet implementation class TopicOrderByTimeThree
 */
public class TopicOrderByTimeThree extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TopicOrderByTimeThree() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cpage = request.getParameter("page");
		int page = cpage==null?1:Integer.parseInt(cpage);
		
		int size = 8;
		
		TopicDao td = new TopicDao();
		
		Topic topic = new Topic();

		
		try {
			
			
			List<Topic> tl = new ArrayList<Topic>();
			List<Topic> tlist = (List<Topic>)request.getAttribute("tlist2");
			for(int i = 1 ; i<tlist.size()+1;i++){
				if(i >=( (page-1)*size+1) && i<=(page*size)){
					tl.add(tlist.get(i-1));

				}
			}
			int count = tlist.size();
			
			int totalPage = count/size;
			
			if(count%size!=0) {
				totalPage++;
			}
			
			
			//��ҳ��ѯ
			/*List<Topic> tlist = td.selectBlur(topic.gettTopic());*/
			
			//��ȡ���÷�Χ
			request.setAttribute("page", page);
			request.setAttribute("total", totalPage);
			request.setAttribute("tl", tl);
			
			request.getRequestDispatcher("SelectSectionThree").forward(request, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
