package com.zr.yahoo.ctrl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.zr.yahoo.bean.Section;
import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.SectionDao;
import com.zr.yahoo.dao.TopicDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class Register
 */
@WebServlet("/InsertTopic")
public class InsertTopic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertTopic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		
		
		
		//���ݿ��ֶ�
		int sid = 0;
		String uname = null;
		String ttopic = null;
		String tcontents  = null;
		Date date=new Date();
		SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String ttime=s.format(date);
		String temotion = null;
		
		try {	
			List<org.apache.commons.fileupload.FileItem> items = upload.parseRequest(request);
			for(FileItem item:items){
				if(item.isFormField()){
					String fieldName = item.getFieldName();
					if(fieldName.equals("topicName")){
						sid = (Integer.parseInt(item.getString("UTF-8")));
					}else if(fieldName.equals("topicTitle")){
						ttopic = (item.getString("UTF-8"));
					}else if(fieldName.equals("topicContaint")){
						tcontents = (item.getString("UTF-8"));
						if(tcontents.length()>50){
							tcontents=tcontents.substring(0, 50);
						}
					}else if(fieldName.equals("Name")){
						uname = (item.getString("UTF-8"));
					}				
				}else{
					InputStream in=item.getInputStream();
					byte[] buffer=new byte[1024];
					int len=0;
					String fileName=item.getName();
					int index=fileName.lastIndexOf("\\");	
					System.out.println("fileName------"+fileName);
					System.out.println("index------"+index);
					if(index!=-1){
						String filename=fileName.substring(index);		
						String path=getServletContext().getRealPath("/")+"header";
						fileName=path+filename;
						System.out.println("fileName:"+fileName);
						temotion=filename;//ͷ���ļ���
						OutputStream out=new FileOutputStream(fileName);
	    				while((len=in.read(buffer))!=-1){
						out.write(buffer,0,len);
						}
	    				out.close();
						in.close();
					}else if(fileName!=""){
						String path=getServletContext().getRealPath("\\")+"\\header\\";
						String filename=path+fileName;
						System.out.println("fileName:"+filename);
						temotion=fileName;//ͷ���ļ���
						OutputStream out=new FileOutputStream(filename);
	    				while((len=in.read(buffer))!=-1){
						out.write(buffer,0,len);
						}
	    				out.close();
						in.close();
					}/*else{
						if(topicFile.equals("")){
							temotion = "\\u23.png";
						}					
					}*/
				}
				
			}//forѭ������
			
			//�����
			SectionDao sd = new SectionDao();
			List<Section> slist = sd.selectAll();
			
			TopicDao td = new TopicDao();					
			Topic topic = new Topic();
			
			UsersDao udao = new UsersDao();
			Users user = udao.selectByUname(uname);
									
			topic.settUid(user.getUserId());
			topic.settSid(sid);
			topic.settTopic(ttopic);
			topic.settContents(tcontents);
			topic.settTime(ttime);
			topic.settEmotion(temotion);
		
			request.setAttribute("topic", topic);
			request.setAttribute("slist", slist);
			td.insertTopic(topic);
			request.getRequestDispatcher("ShouYe").forward(request,response);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}

}
