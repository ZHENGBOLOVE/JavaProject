package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Section;
import com.zr.yahoo.dao.SectionDao;

/**
 * Servlet implementation class SelectSectionByPage
 */
@WebServlet("/SelectSectionByPage")
public class SelectSectionByPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectSectionByPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String page = request.getParameter("page");
		int p = page==null?1:Integer.parseInt(page);
		
		//ÿҳ�ܷŶ���������
		int size = 5;
		
		SectionDao sd = new SectionDao();
		
		int count;
		//��ҳ��
		int totalpage;
		try {
			count = sd.countSection();
			totalpage = count/size;
			
			if(count%size!=0){
				totalpage++;
			}
			
			//�����÷�Χ
			List<Section> slist = sd.selectByPage(p, size);
			System.out.println(slist.size());
			request.setAttribute("page", p);
			request.setAttribute("total",totalpage);
			request.setAttribute("slist", slist);
			
			//����ת��
			request.getRequestDispatcher("ManagerSection").forward(request, response);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
