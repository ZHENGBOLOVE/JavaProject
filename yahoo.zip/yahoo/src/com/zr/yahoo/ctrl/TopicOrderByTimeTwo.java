package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.dao.TopicDao;

/**
 * Servlet implementation class TopicOrderByTimeTwo
 */
public class TopicOrderByTimeTwo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TopicOrderByTimeTwo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cpage = request.getParameter("page");
		int id = Integer.parseInt(request.getParameter("tid"));
		int page = cpage==null?1:Integer.parseInt(cpage);
		
		int size = 8;
		
		TopicDao td = new TopicDao();

		
		try {
			
			int count = td.getCount();
			
			int totalPage = count/size;
			
			if(count%size!=0) {
				totalPage++;
			}
			
			//��ҳ��ѯ
			List<Topic> tlist = td.selectByTopicSid(id);
			
			//��ȡ���÷�Χ
			request.setAttribute("page", page);
			request.setAttribute("total", totalPage);
			request.setAttribute("tlist1", tlist);
			
			request.getRequestDispatcher("SelectSectionTwo").forward(request, response);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
