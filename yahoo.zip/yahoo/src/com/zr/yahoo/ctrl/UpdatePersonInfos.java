package com.zr.yahoo.ctrl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class UpdatePersonInfos
 */
public class UpdatePersonInfos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePersonInfos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		
		Date date=new Date();
		SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd ");
		String times=s.format(date);
		
		String userid = null;
		String uname=null;
		String upassword=null;
		String ubirthday=null;
		String uemotion=null;
		String usex = null;
		String uregdate = times;
		String utype = null;
		
		try {	
			List<FileItem> items = upload.parseRequest(request);
			for(FileItem item:items){
				if(item.isFormField()){
					String fieldName = item.getFieldName();
					if(fieldName.equals("userId")){
						userid = (item.getString("UTF-8"));
					} else if(fieldName.equals("userName")){
						uname = (item.getString("UTF-8"));
					}else if(fieldName.equals("password")){
						upassword = (item.getString("UTF-8"));
					}else if(fieldName.equals("ubirthday")){
						ubirthday = (item.getString("UTF-8"));
					}else if(fieldName.equals("sex")){
						usex = (item.getString("UTF-8"));
					}/*else if(fieldName.equals("upload")){
						uemotion = (item.getString("UTF-8"));
					}*/else if(fieldName.equals("Regdate")){
						uregdate = (item.getString("UTF-8"));
					}else if(fieldName.equals("type")){
						utype = (item.getString("UTF-8"));
					}
				}else{
					InputStream in=item.getInputStream();
					byte[] buffer=new byte[1024];
					int len=0;
					String fileName=item.getName();
					int index=fileName.lastIndexOf("\\");	
					if(index!=-1){
						String filename=fileName.substring(index);		
						String path=getServletContext().getRealPath("/")+"header";
						fileName=path+filename;
						
						uemotion = filename;//ͷ���ļ���
						OutputStream out=new FileOutputStream(fileName);
	    				while((len=in.read(buffer))!=-1){
	    					out.write(buffer,0,len);
						}
	    				out.close();
						in.close();
					}else if(fileName!=""){
						String path=getServletContext().getRealPath("\\")+"\\header\\";
						String filename=path+fileName;
						
						uemotion=fileName;//ͷ���ļ���
						OutputStream out=new FileOutputStream(filename);
	    				while((len=in.read(buffer))!=-1){
	    					out.write(buffer,0,len);
						}
	    				out.close();
						in.close();
					}
				}
				
			}//forѭ������
			
			
			Users user=new Users();
			user.setUserId(Integer.parseInt(userid));
			user.setuName(uname);
			user.setuPassword(upassword);
			user.setuBirthday(ubirthday);
			user.setuEmotion(uemotion);
			user.setuSex(Integer.parseInt(usex));
			user.setuRegdate(uregdate);
			user.setuType(Integer.parseInt(utype));
			
			UsersDao ud=new UsersDao();
			
			ud.updateUsers(user);
			
			/*HttpSession session=request.getSession();
			
			session.setAttribute("users", user);*/
			request.setAttribute("users", user);
			
			request.getRequestDispatcher("TopicOrderByTime").forward(request,response);
			
			/*response.sendRedirect("index.jsp");*/

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
