package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Reply;
import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.ReplyDao;
import com.zr.yahoo.dao.TopicDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class Reply
 */
public class ReplyTopic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReplyTopic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				//��ȡֵ	
				int rid = Integer.parseInt(request.getParameter("rtId"));
				int uId = Integer.parseInt(request.getParameter("uId"));
				String replyTopic = request.getParameter("replyTopic");
				String content = request.getParameter("content");
				
				ReplyDao rd = new ReplyDao();
				Reply r = new Reply();
				UsersDao ud = new UsersDao();
				TopicDao td = new TopicDao();
				
				//ʱ��
				SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd hh:mm:ss");
				String rTime = sdf.format(new Date());
				
				Users u;
				try {
					u = ud.selectById(uId);
					Topic t = td.selectById(rid);
					
					r.setrTid(t.gettId());
					r.setrUid(u.getUserId());
					r.setrTopic(replyTopic);
					r.setrContents(content);
					r.setrTime(rTime);
					rd.InsertReply(r);
					
					response.sendRedirect("UpdateReplyCount?tid="+t.gettId());
					
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
