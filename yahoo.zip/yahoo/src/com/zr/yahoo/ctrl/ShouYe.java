package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Section;
import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.SectionDao;
import com.zr.yahoo.dao.TopicDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class GetAllContent
 */

public class ShouYe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShouYe() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		
		TopicDao td = new TopicDao();
	
		
		List<Users> ulist;
		try {
			List<Topic> tlist1 = td.selectAllByReplyCount();
			List<Topic> tlist2 = td.selectAllByClick();
			//��Id�������÷�Χ��
			/*request.setAttribute("tid", tid);*/
			request.setAttribute("tlist1", tlist1);
			request.setAttribute("tlist2", tlist2);
			request.getRequestDispatcher("TopicOrderByTime").forward(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
