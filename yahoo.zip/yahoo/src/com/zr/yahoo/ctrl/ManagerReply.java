package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Reply;
import com.zr.yahoo.bean.Topic;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.ReplyDao;
import com.zr.yahoo.dao.TopicDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class ManagerReply
 */
@WebServlet("/ManagerReply")
public class ManagerReply extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ManagerReply() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ReplyDao rd = new ReplyDao();
		
		TopicDao td = new TopicDao();
		
		UsersDao ud = new UsersDao();
		
		try {
			//List<Reply> rlist = rd.selectAll();
			List<Topic> tlist = td.selectAll();
			List<Users> ulist = ud.selectAllUsers();
			
			//request.setAttribute("rlist", rlist);
			request.setAttribute("tlist", tlist);
			request.setAttribute("ulist", ulist);
			
			request.getRequestDispatcher("ManagerReply.jsp").forward(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
