package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Section;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.SectionDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class UpdateSectionById
 */
@WebServlet("/UpdateSectionById")
public class UpdateSectionById extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateSectionById() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��ȡId
		int id = Integer.parseInt(request.getParameter("id"));
		//��ȡ�����
		String sectionName = request.getParameter("sectionName");
		//��ȡ�û�����
		String name = request.getParameter("name");
		//��ȡ�����
		int pointTotal = Integer.parseInt(request.getParameter("pointTotal"));
		//��ȡ��������
		int topicTotal = Integer.parseInt(request.getParameter("topicTotal"));
		
		SectionDao sd = new SectionDao();
		Section s = new Section();
		Users u = new Users();
		UsersDao ud = new UsersDao();
		
		s.setsName(sectionName);
		Users user;
		try {
			user = ud.selectByUname(name);
			s.setsId(id);
			s.setsMasterId(user.getUserId());
			s.setsClickCount(pointTotal);
			s.setsTopicCount(topicTotal);
			
			sd.updateSection(s);
			
			response.sendRedirect("SelectSectionByPage");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
