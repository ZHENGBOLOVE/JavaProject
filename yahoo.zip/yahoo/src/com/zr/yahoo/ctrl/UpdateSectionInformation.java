package com.zr.yahoo.ctrl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.yahoo.bean.Section;
import com.zr.yahoo.bean.Users;
import com.zr.yahoo.dao.SectionDao;
import com.zr.yahoo.dao.UsersDao;

/**
 * Servlet implementation class UpdateSectionInformation
 */
@WebServlet("/UpdateSectionInformation")
public class UpdateSectionInformation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateSectionInformation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//��ȡ����
		int sid = Integer.parseInt(request.getParameter("sid"));
		System.out.println(sid);
		SectionDao sd = new SectionDao();
		UsersDao ud = new UsersDao();
		
		try {
			Section sec = sd.selectById(sid);
			
			List<Users> ulist = ud.selectAllUsers();
			
			request.setAttribute("sec", sec);
			
			request.setAttribute("ulist", ulist);
			
			request.getRequestDispatcher("UpdateSectionInformation.jsp").forward(request,response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
