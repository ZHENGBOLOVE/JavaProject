package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.yahoo.bean.Users;

public class UsersDao extends BaseDao{
	public void insertUsers(Users user) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "insert into users values(qe_v.nextval,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,user.getuName());
		ps.setString(2,user.getuPassword());
		ps.setString(3,user.getuBirthday());
		ps.setString(4,user.getuEmotion());
		ps.setInt(5,user.getuSex());
		ps.setString(6,user.getuRegdate());
		ps.setInt(7,user.getuType());
		
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	public List<Users> selectAllUsers() throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from users";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Users> userlist = new ArrayList<Users>();
		while(rs.next()){
			Users user = new Users();
			user.setUserId(rs.getInt(1));
			user.setuName(rs.getString(2));
			user.setuPassword(rs.getString(3));
			user.setuBirthday(rs.getString(4));
			user.setuEmotion(rs.getString(5));
			user.setuSex(rs.getInt(6));
			user.setuRegdate(rs.getString(7));
			user.setuType(rs.getInt(8));
			
			userlist.add(user);
		}
		return userlist;
	}
	public Users selectById(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from users where userid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ResultSet rs = ps.executeQuery();
		Users user = null;
		if(rs.next()){
			user = new Users();
			user.setUserId(rs.getInt(1));
			user.setuName(rs.getString(2));
			user.setuPassword(rs.getString(3));
			user.setuBirthday(rs.getString(4));
			user.setuEmotion(rs.getString(5));
			user.setuSex(rs.getInt(6));
			user.setuRegdate(rs.getString(7));
			user.setuType(rs.getInt(8));
		}
		return user;
	}
	
	public Users selectByUname(String uName) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from users where uname=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,uName);
		ResultSet rs = ps.executeQuery();
		Users user = null;
		if(rs.next()){
			user = new Users();
			user.setUserId(rs.getInt(1));
			user.setuName(rs.getString(2));
			user.setuPassword(rs.getString(3));
			user.setuBirthday(rs.getString(4));
			user.setuEmotion(rs.getString(5));
			user.setuSex(rs.getInt(6));
			user.setuRegdate(rs.getString(7));
			user.setuType(rs.getInt(8));
		}
		return user;
	}
	
	public void updateUsers(Users u) throws SQLException, ClassNotFoundException {
		PreparedStatement ps = getConn().prepareStatement("update users set uname=?,upassword=?,ubirthday=?,uemotion=?,usex=?,uregdate=?,utype=? where userid=?");
		ps.setString(1, u.getuName());
		ps.setString(2, u.getuPassword());
		ps.setString(3, u.getuBirthday());
		ps.setString(4, u.getuEmotion());
		ps.setInt(5, u.getuSex());
		ps.setString(6, u.getuRegdate());
		ps.setInt(7, u.getuType());
		ps.setInt(8,u.getUserId());
		ps.executeUpdate();
		ps.close();
		this.closeconn();
	}
}
