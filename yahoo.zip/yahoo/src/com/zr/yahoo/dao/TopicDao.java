package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.yahoo.bean.Topic;

public class TopicDao extends BaseDao {
	public void insertTopic(Topic topic) throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "insert into topic values(qe_v.nextval,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, topic.gettSid());
		ps.setInt(2, topic.gettUid());
		ps.setInt(3, topic.gettReplyCount());
		ps.setString(4, topic.gettEmotion());
		ps.setString(5, topic.gettTopic());
		ps.setString(6, topic.gettContents());
		ps.setString(7, topic.gettTime());
		ps.setInt(8, topic.gettClickCount());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}

	public void deleteTopic(int pk) throws SQLException, ClassNotFoundException {
		Connection conn = getConn();
		String sql = "delete from topic where tid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, pk);
		ps.executeUpdate();
		ps.close();
		conn.close();
	}

	public void updateTopic(Topic topic) throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "update topic set tSid=?,tUid=?,tReplyCount=?,tEmotion=?,tTopic=?,tContents=?,tTime=?,tClickCount=? where tId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, topic.gettSid());
		ps.setInt(2, topic.gettUid());
		ps.setInt(3, topic.gettReplyCount());
		ps.setString(4, topic.gettEmotion());
		ps.setString(5, topic.gettTopic());
		ps.setString(6, topic.gettContents());
		ps.setString(7, topic.gettTime());
		ps.setInt(8, topic.gettClickCount());
		ps.setInt(9, topic.gettId());
		ps.close();
		conn.close();
	}

	public List<Topic> selectAll() throws SQLException, ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		return tlist;
	}

	@SuppressWarnings("null")
	public Topic selectById(int pk) throws SQLException, ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic where tid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, pk);
		ResultSet rs = ps.executeQuery();
		Topic t = null;
		if (rs.next()) {
			t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
		}
		return t;
	}

	public int countTopic() throws SQLException, ClassNotFoundException {
		int count = 0;
		PreparedStatement ps = getConn().prepareStatement(
				"select count(*) from topic");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}
	
	//��ҳ��ѯ
	public List<Topic> selectByPage(int curpage, int size) throws SQLException,
			ClassNotFoundException {
		PreparedStatement ps = getConn()
				.prepareStatement(
						"select t.* from (select e.*,rownum num from (select * from topic) e where rownum<=?) t where t.num>=?");
		ps.setInt(1, curpage * size);
		ps.setInt(2, (curpage - 1) * size + 1);
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		return tlist;
	}

	// �б�����ʱ��˳����������
	public List<Topic> orderByTopic(int pk) throws ClassNotFoundException,
			SQLException {
		PreparedStatement ps = getConn().prepareStatement(
				"select * from topic where tuid=? order by ttime desc");
		ps.setInt(1, pk);
		List<Topic> list = new ArrayList<Topic>();
		ResultSet rs = ps.executeQuery();
		Topic topic = null;
		while (rs.next()) {
			topic = new Topic();
			topic.settId(rs.getInt(1));
			topic.settSid(rs.getInt(2));
			topic.settUid(rs.getInt(3));
			topic.settReplyCount(rs.getInt(4));
			topic.settEmotion(rs.getString(5));
			topic.settTopic(rs.getString(6));
			topic.settContents(rs.getString(7));
			topic.settTime(rs.getString(8));
			topic.settClickCount(rs.getInt(9));
			System.out.println(123);
			list.add(topic);
		}
		rs.close();
		ps.close();
		this.closeconn();
		return list;
	}

	// ��ȡ��¼
	public int getCount() throws Exception {
		int count = 0;
		PreparedStatement ps = getConn().prepareStatement(
				"select count(*) from topic");
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}

	// ��ҳ��ѯ
	public List<Topic> selectByTopicPage(int curpage, int size)
			throws Exception {
		List<Topic> list = new ArrayList<Topic>();
		String sql = "select t.* from (select e.*,rownum num from (select * from topic) e where rownum<=?) t where t.num>=? order by ttime desc";
		PreparedStatement ps = getConn().prepareStatement(sql);
		ps.setInt(1, curpage * size);
		ps.setInt(2, (curpage - 1) * size + 1);
		ResultSet rs = ps.executeQuery();
		UsersDao ud = new UsersDao();
		SectionDao sd = new SectionDao();
		while (rs.next()) {
			Topic topic = new Topic();
			topic.settSid(rs.getInt(1));
			topic.settId(rs.getInt(2));
			topic.settUid(rs.getInt(3));
			topic.settReplyCount(rs.getInt(4));
			topic.settEmotion(rs.getString(5));
			topic.settTopic(rs.getString(6));
			topic.settContents(rs.getString(7));
			topic.settTime(rs.getString(8));
			topic.settClickCount(rs.getInt(9));
			list.add(topic);
		}
		rs.close();
		ps.close();
		this.closeconn();
		return list;
	}

	// ���յ��������
	public List<Topic> selectAllByClick() throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic order by tclickcount desc";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		return tlist;
	}

	// ������������
	public List<Topic> selectAllByReplyCount() throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic order by treplycount desc";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		return tlist;
	}
	
	//���Id��ѯ
	public List<Topic> selectByTopicSid(int id) throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic where tsid=? order by ttime desc";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		return tlist;
	}
	
	//ģ����ѯ
	public List<Topic> selectBlur(String str) throws SQLException, ClassNotFoundException {
		Connection conn = getConn();
		String sql = "select * from topic where ttopic like ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, "%"+str+"%");
		ResultSet rs = ps.executeQuery();
		List<Topic> tlist = new ArrayList<Topic>();
		while (rs.next()) {
			Topic t = new Topic();
			t.settId(rs.getInt(1));
			t.settSid(rs.getInt(2));
			t.settUid(rs.getInt(3));
			t.settReplyCount(rs.getInt(4));
			t.settEmotion(rs.getString(5));
			t.settTopic(rs.getString(6));
			t.settContents(rs.getString(7));
			t.settTime(rs.getString(8));
			t.settClickCount(rs.getInt(9));
			tlist.add(t);
		}
		rs.close();
		ps.close();
		closeconn();
		return tlist;
	}
	
	
	//�޸Ļ�����
	public void updateTopicByReplyCount(Topic topic) throws SQLException,
			ClassNotFoundException {
		Connection conn = getConn();
		String sql = "update topic set tReplyCount=? where tId=?";
		PreparedStatement ps = conn.prepareStatement(sql);
	
		ps.setInt(1, topic.gettReplyCount());
		ps.setInt(2, topic.gettId());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}

}
