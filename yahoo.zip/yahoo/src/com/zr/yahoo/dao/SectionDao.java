package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.yahoo.bean.Section;

public class SectionDao extends BaseDao{
	public void insertSection(Section s) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "insert into section values(qe_v.nextval,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,s.getsName());
		ps.setInt(2,s.getsMasterId());
		ps.setInt(3,s.getsClickCount());
		ps.setInt(4,s.getsTopicCount());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	public void deleteSection(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "delete from section where sid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	public void updateSection(Section s) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "update section set sname=?,smasterid=?,sclickcount=?,stopiccount=? where sid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,s.getsName());
		ps.setInt(2,s.getsMasterId());
		ps.setInt(3,s.getsClickCount());
		ps.setInt(4,s.getsTopicCount());
		ps.setInt(5,s.getsId());
		ps.executeQuery();
		ps.close();
		conn.close();
	}
	public List<Section> selectAll() throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from section ";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Section> slist = new ArrayList<Section>();
		while(rs.next()){
			Section s = new Section();
			s.setsId(rs.getInt(1));
			s.setsName(rs.getString(2));
			s.setsMasterId(rs.getInt(3));
			s.setsClickCount(rs.getInt(4));
			s.setsTopicCount(rs.getInt(5));
			slist.add(s);
		}
		return slist;
	}
	public Section selectById(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from section where sid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ResultSet rs = ps.executeQuery();
		Section s = null;
		while(rs.next()){
			s = new Section();
			s.setsId(rs.getInt(1));
			s.setsName(rs.getString(2));
			s.setsMasterId(rs.getInt(3));
			s.setsClickCount(rs.getInt(4));
			s.setsTopicCount(rs.getInt(5));		
		}
		return s;
	}
	
	public Section selectByName(String pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from section where sname=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,pk);
		ResultSet rs = ps.executeQuery();
		Section s = null;
		while(rs.next()){
			s = new Section();
			s.setsId(rs.getInt(1));
			s.setsName(rs.getString(2));
			s.setsMasterId(rs.getInt(3));
			s.setsClickCount(rs.getInt(4));
			s.setsTopicCount(rs.getInt(5));		
		}
		return s;
	}
	
	public int countSection() throws SQLException, ClassNotFoundException {
		int count = 0;
		PreparedStatement ps = getConn().prepareStatement("select count(*) from section");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}
	
	public List<Section> selectByPage(int curpage,int size) throws SQLException, ClassNotFoundException {
		PreparedStatement ps = getConn().prepareStatement("select t.* from (select e.*,rownum num from (select * from section) e where rownum<=?) t where t.num>=?");
		ps.setInt(1, curpage*size);
		ps.setInt(2, (curpage-1)*size+1);
		List<Section> slist = new ArrayList<Section>();
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			Section s = new Section();
			s.setsId(rs.getInt(1));
			s.setsName(rs.getString(2));
			s.setsMasterId(rs.getInt(3));
			s.setsClickCount(rs.getInt(4));
			s.setsTopicCount(rs.getInt(5));
			slist.add(s);
		}
		return slist;
	}
	
	//�����������
	public List<Section> selectBySectionName(String name) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select ? from section";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,name);
		List<Section> slist = new ArrayList<Section>();
		ResultSet rs = ps.executeQuery();
		Section s = null;
		while(rs.next()){
			s = new Section();
			/*s.setsId(rs.getInt(1));*/
			s.setsName(rs.getString(1));
			/*s.setsMasterId(rs.getInt(3));
			s.setsClickCount(rs.getInt(4));
			s.setsTopicCount(rs.getInt(5));	*/
			slist.add(s);
		}
		return slist;
	}
}









