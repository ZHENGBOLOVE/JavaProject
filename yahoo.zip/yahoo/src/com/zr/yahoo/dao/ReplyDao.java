package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.yahoo.bean.Reply;
import com.zr.yahoo.bean.Topic;

public class ReplyDao extends BaseDao {
	public void InsertReply(Reply r) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "insert into reply values(qe_v.nextval,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,r.getrTid());
		ps.setInt(2,r.getrUid());
		ps.setString(3,r.getrEmotion());
		ps.setString(4,r.getrTopic());
		ps.setString(5,r.getrContents());
		ps.setString(6,r.getrTime());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	public void deleteReply(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn(); 
		String sql = "delete from reply where rid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	public void updateReply(Reply r) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "update reply set rtid=?,ruid=?,remoyion=?,rtopic=?,rcontents=?,rtime=? where rid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,r.getrTid());
		ps.setInt(2,r.getrUid());
		ps.setString(3,r.getrEmotion());
		ps.setString(4,r.getrTopic());
		ps.setString(5,r.getrContents());
		ps.setString(6,r.getrTime());
		ps.setInt(7,r.getrId());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	public List<Reply> selectAll() throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from reply";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Reply> rlist = new ArrayList<Reply>();
		while(rs.next()){
			Reply r = new Reply();
			r.setrId(rs.getInt(1));
			r.setrTid(rs.getInt(2));
			r.setrUid(rs.getInt(3));
			r.setrEmotion(rs.getString(4));
			r.setrTopic(rs.getString(5));
			r.setrContents(rs.getString(6));
			r.setrTime(rs.getString(7));
			rlist.add(r);
		}
		return rlist;
	} 
	
	public Reply selectById(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from reply where rid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ResultSet rs = ps.executeQuery();
		Reply r = null;
		if(rs.next()){
			r = new Reply();
			r.setrId(rs.getInt(1));
			r.setrTid(rs.getInt(2));
			r.setrUid(rs.getInt(3));
			r.setrEmotion(rs.getString(4));
			r.setrTopic(rs.getString(5));
			r.setrContents(rs.getString(6));
			r.setrTime(rs.getString(7));
		}
		return r;
	}
	
	public int countReplyDao() throws SQLException, ClassNotFoundException {
		int count = 0;
		PreparedStatement ps = getConn().prepareStatement("select count(*) from reply");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}
	
	public List<Reply> selectByPage(int curpage,int size) throws SQLException, ClassNotFoundException {
		PreparedStatement ps = getConn().prepareStatement("select t.* from (select e.*,rownum num from (select * from reply) e where rownum<=?) t where t.num>=?");
		ps.setInt(1, curpage*size);
		ps.setInt(2, (curpage-1)*size+1);
		ResultSet rs = ps.executeQuery();
		List<Reply> rlist = new ArrayList<Reply>();
		while(rs.next()){
			Reply r = new Reply();
			r.setrId(rs.getInt(1));
			r.setrTid(rs.getInt(2));
			r.setrUid(rs.getInt(3));
			r.setrEmotion(rs.getString(4));
			r.setrTopic(rs.getString(5));
			r.setrContents(rs.getString(6));
			r.setrTime(rs.getString(7));
			rlist.add(r);
		}
		return rlist;
	}
	
	//�޸ĵ����
	public void updateReplyByClick(Reply r) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "update reply set rtid=?,ruid=?,remoyion=?,rtopic=?,rcontents=?,rtime=? where rid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,r.getrTid());
		ps.setInt(2,r.getrUid());
		ps.setString(3,r.getrEmotion());
		ps.setString(4,r.getrTopic());
		ps.setString(5,r.getrContents());
		ps.setString(6,r.getrTime());
		ps.setInt(7,r.getrId());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	//rtid
	public List<Reply> selectByrTid(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from reply where rtid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		List<Reply> rlist = new ArrayList<Reply>();
		ps.setInt(1,pk);
		ResultSet rs = ps.executeQuery();
		Reply r = null;
		while(rs.next()){
			r = new Reply();
			r.setrId(rs.getInt(1));
			r.setrTid(rs.getInt(2));
			r.setrUid(rs.getInt(3));
			r.setrEmotion(rs.getString(4));
			r.setrTopic(rs.getString(5));
			r.setrContents(rs.getString(6));
			r.setrTime(rs.getString(7));
			rlist.add(r);
		}
		return rlist;
	}
	
}
