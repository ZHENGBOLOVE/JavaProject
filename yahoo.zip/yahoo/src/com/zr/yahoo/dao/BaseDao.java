package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BaseDao {
	private static Connection conn;
	public static Connection getConn() throws SQLException, ClassNotFoundException{
		if(conn==null||conn.isClosed()){
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
			return conn;
		}else{
			return conn;
		}
	}
	public static void closeconn() throws SQLException{
		if(conn!=null||!conn.isClosed()){
			conn.close();
		}
	}	
}
