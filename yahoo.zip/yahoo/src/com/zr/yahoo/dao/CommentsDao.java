package com.zr.yahoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.yahoo.bean.Comments;

public class CommentsDao extends BaseDao {
	public void insertComments(Comments c) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "insert into comments values(qe_e,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,c.getcRid());
		ps.setInt(2,c.getcTid());
		ps.setString(3,c.getcContents());
		ps.setInt(4,c.getcZan());
		ps.setInt(5,c.getcNotZan());
		ps.setInt(6,c.getcUserId());
		ps.setString(7,c.getcTime());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	public void deleteComments(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "delete from comments where cid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ps.executeUpdate();
		ps.close();
		conn.close();
		
	}
	
	public void updateComments(Comments c) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "update comments set crid=?,ctid=?,ccontent=?,czan=?,ccai=?,cuserid=?,ctime=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,c.getcRid());
		ps.setInt(2,c.getcTid());
		ps.setString(3,c.getcContents());
		ps.setInt(4,c.getcZan());
		ps.setInt(5,c.getcNotZan());
		ps.setInt(6,c.getcUserId());
		ps.setString(7,c.getcTime());
		ps.executeUpdate();
		ps.close();
		conn.close();
	}
	
	public List<Comments> selectAll() throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from comments";
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		List<Comments> clist = new ArrayList<Comments>();
		while(rs.next()){
			Comments c = new Comments();
			c.setcId(rs.getInt(1));
			c.setcRid(rs.getInt(2));
			c.setcTid(rs.getInt(3));
			c.setcContents(rs.getString(4));
			c.setcZan(rs.getInt(5));
			c.setcNotZan(rs.getInt(6));
			c.setcUserId(rs.getInt(7));
			c.setcTime(rs.getString(8));
			clist.add(c);
		}
		return clist;
	}
	
	public Comments selectById(int pk) throws SQLException, ClassNotFoundException{
		Connection conn = getConn();
		String sql = "select * from comments where cid=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,pk);
		ResultSet rs = ps.executeQuery();
		Comments c = null;
		if(rs.next()){
			c = new Comments();
			c.setcId(rs.getInt(1));
			c.setcRid(rs.getInt(2));
			c.setcTid(rs.getInt(3));
			c.setcContents(rs.getString(4));
			c.setcZan(rs.getInt(5));
			c.setcNotZan(rs.getInt(6));
			c.setcUserId(rs.getInt(7));
			c.setcTime(rs.getString(8));
		}
		return c;
	}

}
