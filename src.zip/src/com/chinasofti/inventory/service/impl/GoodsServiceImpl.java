package com.chinasofti.inventory.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.chinasofti.inventory.dao.GoodsDao;
import com.chinasofti.inventory.entity.Goods;
import com.chinasofti.inventory.service.GoodsService;

/**
 * ����������Ʒ����ҵ���ʵ����
 * 
 * @author: zhengbo
 * @date�� ���ڣ�2017��4��24�� ʱ�䣺����3:11:35
 * @version 1.7.0_65
 */
@Service
@Transactional
public class GoodsServiceImpl implements GoodsService {

	// ע��dao
	@Autowired
	private GoodsDao goodsDao;

	@Override
	public void insert(Goods goods) {
		goodsDao.insert(goods);
	}

	@Override
	public void delete(int goodsId) {
		goodsDao.delete(goodsId);
	}

	@Override
	public void update(Goods goods) {
		goodsDao.update(goods);
	}

	@Override
	public Goods selectById(int goodsId) {
		return goodsDao.selectById(goodsId);
	}

	@Override
	public List<Goods> selectAll() {
		return goodsDao.selectAll();
	}

	@Override
	public int getTotalPage(int size) {
		// �ܸ���
		int count = goodsDao.getCount();
		// �ּܷ�ҳ
		int total = count / size;
		if (count % size != 0) {
			total++;
		}
		return total;
	}

	@Override
	public List<Goods> selectByPage(int curPage, int size) {
		// ����Map����
		Map map = new HashMap();
		// ���ҳ��
		map.put("max", curPage * size);
		// ��Сҳ��
		map.put("min", (curPage - 1) * size + 1);

		return goodsDao.selectByPage(map);
	}

	@Override
	public void deleteByIds(String[] goodsId) {
		goodsDao.deleteByIds(goodsId);
	}

	@Override
	public List<Goods> selectAllByLike(String gname) {
		
		return goodsDao.selectAllByLike(gname);
	}

}
