package com.chinasofti.inventory.ctrl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.chinasofti.inventory.entity.Company;
import com.chinasofti.inventory.entity.Goods;
import com.chinasofti.inventory.entity.InBound;
import com.chinasofti.inventory.entity.InOrder;
import com.chinasofti.inventory.entity.Invent;
import com.chinasofti.inventory.service.CompanyService;
import com.chinasofti.inventory.service.GoodsService;
import com.chinasofti.inventory.service.InBoundService;
import com.chinasofti.inventory.service.InOrderService;
import com.chinasofti.inventory.service.InventService;

/**
 * �������������ϸ���Ŀ�������
 * 
 * @author: zhengbo
 * @date�� ���ڣ�2017��4��26�� ʱ�䣺����10:21:47
 * @version 1.7.0_65
 */
@Controller
@RequestMapping("/inbound")
public class InBoundCtrl {

	// ע��Service
	@Autowired
	private CompanyService cService;
	@Autowired
	private InBoundService ibService;
	@Autowired
	private InOrderService ioService;
	@Autowired
	private GoodsService gService;
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private InventService iService;

	/**
	 * 
	 * ������������ѯ����
	 * 
	 * @author: zhengbo
	 * @date�� ���ڣ�2017��4��26�� ʱ�䣺����11:35:59
	 * @return
	 * @version 1.7.0_65
	 */
	@RequestMapping("/selectAll.php")
	public String selectAll() {
		// ��ѯ�����ϸ
		List<InBound> iblist = ibService.selectAll();

		// ��ѯ��ⶩ��
		List<Company> clist = cService.selectAll();
		
		List<InOrder> iolist = ioService.selectAll();
		
		// ��ѯ���л�Ʒ
		List<Goods> glist = gService.selectAll();
		
		// ��ȡ���÷�Χ
		request.setAttribute("iblist", iblist);
		request.setAttribute("iolist", iolist);
		request.setAttribute("glist", glist);
		request.setAttribute("clist", clist);
		/*request.setAttribute("ilist", ilist);*/

		return "inboundManager";
	}

	/**
	 * 
	 * ����������������ѯ����
	 * 
	 * @author: zhengbo
	 * @date�� ���ڣ�2017��4��26�� ʱ�䣺����11:36:10
	 * @return
	 * @version 1.7.0_65
	 */
	@RequestMapping("/selectInBound.php")
	public String selectInBound() {
		// ��ѯ�����ϸ
		List<InBound> iblist = ibService.selectAll();

		// ��ѯ��ⶩ��
		List<InOrder> iolist = ioService.selectAll();

		// ��ѯ���л�Ʒ
		List<Goods> glist = gService.selectAll();

		// ��ȡ���÷�Χ
		request.setAttribute("iblist", iblist);
		request.setAttribute("iolist", iolist);
		request.setAttribute("glist", glist);

		return "addInBound";
	}

	@RequestMapping("/insert.php")
	public String insert(InBound inbound) {
		System.out.println(inbound.getNum());
		System.out.println(inbound.getInOrder().getIoid());
		System.out.println(inbound.getGoods().getGoodsId());
		ibService.insert(inbound);
		Invent invent = iService.selectByGoodsId(inbound.getGoods().getGoodsId());
		System.out.println(invent.getGcount());
		invent.setGcount(invent.getGcount()+inbound.getNum());
		iService.update(invent);

		return "redirect:/inbound/selectInBound.php";
	}
	
	@RequestMapping("/delete.php")
	public String delete(int ibid){
		
		ibService.delete(ibid);
		
		return "redirect:/inbound/fenye.php";
	}
	
	@RequestMapping("/fenye.php")
	public String fenye(Integer cpage) {
		if (cpage == null || cpage < 1) {
			cpage = 1;
		}
		int size=5;
		int totalpage = ibService.getCount(size);
		/*int totalpage = count/size;*/
		
		/*if(count%size!=0){
			totalpage++;
		}*/
		if(cpage>totalpage){
			cpage=totalpage;
		}

		// ��ѯ��ⶩ��
		List<Company> clist = cService.selectAll();
		
		List<InOrder> iolist = ioService.selectAll();
		
		// ��ѯ���л�Ʒ
		List<Goods> glist = gService.selectAll();
		
		// ��ȡ���÷�Χ
		request.setAttribute("iolist", iolist);
		request.setAttribute("glist", glist);
		request.setAttribute("clist", clist);
		List<InBound> iblist = ibService.selectByPage(cpage, size);
		
		request.setAttribute("curpage", cpage);
		request.setAttribute("totalpage", totalpage);
		request.setAttribute("iblist", iblist);
		
		return "inboundManager";
	}

}
